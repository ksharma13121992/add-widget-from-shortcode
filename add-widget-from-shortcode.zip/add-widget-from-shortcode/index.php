<?php
/*
Plugin Name:    add-widget-from-shortcode
Description:    Add Widget/Widgets from add shortcode to post or page.
Author:         Khushboo Sharma
Version:        0.0.1
Text Domain:    test
*/


class Widget_Shortcode {
	private static $instance = null;
	public static function get_instance() {
		return null == self::$instance ? self::$instance = new self : self::$instance;
	}

	private function __construct() {
		add_shortcode( 'widget', array( $this, 'shortcode' ) );
		add_action( 'plugins_loaded', array( $this, 'i18n' ), 5 );
		add_action( 'widgets_init', array( $this, 'custom_widget_sidebar' ), 20 );
		add_action( 'in_widget_form', array( $this, 'in_widget_form' ), 10, 3 );
		add_filter( 'mce_external_plugins', array( $this, 'mce_external_plugins' ) );
		add_filter( 'mce_buttons', array( $this, 'mce_buttons' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'editor_parameters' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'editor_parameters' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$atts['echo'] = false;
		return $this->do_widget( $atts );
	}

	function custom_widget_sidebar() {
		register_sidebar( array(
			'name' => __( 'custom_widget_area', 'custom_widget' ),
			'description'	=> __( 'This widget area can be used for [widget] shortcode.', 'custom_widget' ),
			'id' => 'custom_widget',
			'before_widget' => '',
			'after_widget'	=> '',
		) );
	}

	function in_widget_form( $widget, $return, $instance ) {
		echo '<p>' . __( 'Shortcode', 'custom_widget' ) . ': ' . ( ( $widget->number == '__i__' ) ? __( 'Please save this first.', 'custom_widget' ) : '<input type="text" value="' . esc_attr( '[widget id="'. $widget->id .'"]' ) . '" readonly="readonly" class="widefat" onclick="this.select()" />' ) . '</p>';
	}

	function i18n() {
		load_plugin_textdomain( 'custom_widget', false, '/languages' );
	}

	function get_widgets_map() {
		$s_widgets = wp_get_sidebars_widgets();
		$widget_map = array();
		if ( ! empty( $s_widgets ) ){
			foreach( $s_widgets as $position => $widgets ){
				if( ! empty( $widgets) ){
					foreach( $widgets as $widget ){
						$widgets_map[$widget] = $position;
					}
				}
			}
		}
		return $widget_map;
	}

	public function get_widget_options( $widget_id ) {
		global $wp_registered_widgets;
		preg_match( '/(\d+)/', $widget_id, $number );
		$options = get_option( $wp_registered_widgets[$widget_id]['callback'][0]->option_name );
		$instance = $options[$number[0]];
		return $instance;
	}

	function do_widget( $args ) {
		global $_wp_sidebars_widgets, $wp_registered_widgets, $wp_registered_sidebars;
		extract( shortcode_atts( array(
			'id' => '',
			'title' => true, 
			'container_tag' => 'div',
			'container_class' => 'widget %2$s',
			'container_id' => '%1$s',
			'title_tag' => 'h2',
			'title_class' => 'widgettitle',
			'echo' => true
		), $args, 'widget' ) );

		$widget_args = shortcode_atts( array(
			'before_widget' => '<' . $container_tag . ' id="' . $container_id . '" class="' . $container_class . '">',
			'before_title' => '<' . $title_tag . ' class="' . $title_class . '">',
			'after_title' => '</' . $title_tag . '>',
			'after_widget' => '</' . $container_tag . '>',
		), $args );
		extract( $widget_args );

		if( empty( $id ) || ! isset( $wp_registered_widgets[$id] ) )
			return;

		preg_match( '/(\d+)/', $id, $number );
		$options = ( ! empty( $wp_registered_widgets ) && ! empty( $wp_registered_widgets[$id] ) ) ? get_option( $wp_registered_widgets[$id]['callback'][0]->option_name ) : array();
		$instance = isset( $options[$number[0]] ) ? $options[$number[0]] : array();
		$class = get_class( $wp_registered_widgets[$id]['callback'][0] );
		$widgets_map = $this->get_widgets_map();
		$_original_widget_position = $widgets_map[$id];

		// maybe the widget is removed or de-registered
		if( ! $class )
			return;

		$show_title = ( '0' === $title || 'no' === $title || false === $title ) ? false : true;

		/* build the widget args that needs to be filtered through dynamic_sidebar_params */
		$params = array(
			0 => array(
				'name' => isset( $wp_registered_sidebars[$_original_widget_position]['name'] ) ? $wp_registered_sidebars[$_original_widget_position]['name'] : '',
				'id' => isset( $wp_registered_sidebars[$_original_widget_position]['id'] ) ? $wp_registered_sidebars[$_original_widget_position]['id'] : '',
				'description' => isset( $wp_registered_sidebars[$_original_widget_position]['description'] ) ? $wp_registered_sidebars[$_original_widget_position]['description'] : '',
				'before_widget' => $before_widget,
				'before_title' => $before_title,
				'after_title' => $after_title,
				'after_widget' => $after_widget,
				'widget_id' => $id,
				'widget_name' => $wp_registered_widgets[$id]['name']
			),
			1 => array(
				'number' => $number[0]
			)
		);
		$params = apply_filters( 'dynamic_sidebar_params', $params );

		if( ! $show_title ) {
			$params[0]['before_title'] = '<!-- widget_shortcode_before_title -->';
			$params[0]['after_title'] = '<!-- widget_shortcode_after_title -->';
		} elseif( is_string( $title ) && strlen( $title ) > 0 ) {
			$instance['title'] = $title;
		}

		// Substitute HTML id and class attributes into before_widget
		$classname_ = '';
		foreach ( (array) $wp_registered_widgets[$id]['classname'] as $cn ) {
			if ( is_string( $cn ) )
				$classname_ .= '_' . $cn;
			elseif ( is_object($cn) )
				$classname_ .= '_' . get_class( $cn );
		}
		$classname_ = ltrim( $classname_, '_' );
		$params[0]['before_widget'] = sprintf( $params[0]['before_widget'], $id, $classname_ );

		// render the widget
		ob_start();
		echo '<!-- Widget Shortcode -->';
		the_widget( $class, $instance, $params[0] );
		echo '<!-- /Widget Shortcode -->';
		$content = ob_get_clean();

		// supress the title if we wish
		if( ! $show_title ) {
			$content = preg_replace( '/<!-- widget_shortcode_before_title -->(.*?)<!-- widget_shortcode_after_title -->/', '', $content );
		}

		if( $echo !== true )
			return $content;

		echo $content;
	}

	function mce_external_plugins( $plugins ) {
		$plugins['widgetShortcode'] = plugins_url( 'assets/plugin_js.js', __FILE__ );

		return $plugins;
	}

	function mce_buttons( $mce_buttons ) {
		array_push( $mce_buttons, 'separator', 'widgetShortcode' );
		return $mce_buttons;
	}

	function editor_parameters() {
		global $wp_registered_widgets;

		$widgets = array();
		$all_widgets = $this->get_widgets_map();
		if( ! empty( $all_widgets ) ) {
			foreach( $all_widgets as $id => $position ) {
				if( $position == 'custom_widget_area' ) {
					$title = $wp_registered_widgets[$id]['name'];
					$options = $this->get_widget_options( $id );
					if( isset( $options['title'] ) && ! empty( $options['title'] ) ) {
						$title .= ': ' . $options['title'];
					}
					$widgets[] = array(
						'id' => $id,
						'title' =>  $title,
					);
				}
			}
		}
		wp_localize_script( 'editor', 'widgetShortcode', array(
			'title' => __( 'add_widget_from_shortcode', 'custom_widget' ),
			'widgets' => $widgets,
		) );
	}
}
Widget_Shortcode::get_instance();